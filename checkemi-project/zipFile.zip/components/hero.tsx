import { ShieldCheck, Zap, IndianRupee } from "lucide-react"

const BADGES = [
  { icon: IndianRupee, label: "Built for India" },
  { icon: Zap, label: "Instant results" },
  { icon: ShieldCheck, label: "100% private" },
]

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-border/60">
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 opacity-70"
        style={{
          background:
            "radial-gradient(60% 60% at 50% 0%, color-mix(in oklab, var(--primary) 22%, transparent) 0%, transparent 70%)",
        }}
      />
      <div className="mx-auto max-w-6xl px-4 py-16 text-center sm:px-6 sm:py-20">
        <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
          <ShieldCheck className="size-3.5" aria-hidden />
          Free financial calculators
        </span>
        <h1 className="mx-auto mt-5 max-w-3xl text-balance text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl">
          Plan every rupee with <span className="text-primary">CheckEMI</span>
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
          Calculate your loan EMIs, SIP returns, PPF, FD, RD maturity, GST and age in seconds. Accurate formulas,
          beautiful charts, and total privacy — nothing ever leaves your device.
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          {BADGES.map((b) => {
            const Icon = b.icon
            return (
              <span
                key={b.label}
                className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2 text-sm font-medium"
              >
                <Icon className="size-4 text-primary" aria-hidden />
                {b.label}
              </span>
            )
          })}
        </div>
      </div>
    </section>
  )
}
