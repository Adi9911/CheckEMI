import { Hero } from "@/components/hero"
import { CalculatorHub } from "@/components/calculators/calculator-hub"
import { Features } from "@/components/features"
import { Faq } from "@/components/faq"

export default function Page() {
  return (
    <main>
      <Hero />
      <section className="mx-auto max-w-6xl px-4 py-12 sm:px-6" id="calculators">
        <CalculatorHub />
      </section>
      <Features />
      <div className="border-t border-border/60 bg-secondary/20">
        <Faq />
      </div>
    </main>
  )
}
